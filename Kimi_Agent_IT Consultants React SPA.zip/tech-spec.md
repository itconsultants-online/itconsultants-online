# IT Consultants — Technical Specification

---

## 1. Dependencies

| Package | Version | Purpose |
|---------|---------|---------|
| react | ^19.0.0 | UI framework |
| react-dom | ^19.0.0 | DOM renderer |
| lucide-react | ^0.460.0 | Icon library (all section icons) |

**Dev dependencies** (auto-installed by init script):
| Package | Purpose |
|---------|---------|
| vite | Build tool |
| @vitejs/plugin-react | React plugin for Vite |
| typescript | Type system |
| tailwindcss | Utility CSS |
| @types/react | React type definitions |
| @types/react-dom | ReactDOM type definitions |

**No additional packages needed.** All animations are CSS transitions + Canvas 2D (no GSAP, no animation libraries). No shadcn/ui components used — all UI is custom-built.

---

## 2. Component Inventory

### 2.1 shadcn/ui Components

None. All components are custom-built with Tailwind CSS to match the design's glassmorphism aesthetic.

### 2.2 Custom Components

| Component | File | Description |
|-----------|------|-------------|
| Navbar | `src/sections/Navbar.tsx` | Sticky nav with logo, links, CTA, mobile menu |
| Hero | `src/sections/Hero.tsx` | Full-viewport hero with headline, subtitle, CTAs |
| Services | `src/sections/Services.tsx` | 5 service cards in responsive grid |
| About | `src/sections/About.tsx` | Two-column: company info + stat counters |
| Contact | `src/sections/Contact.tsx` | Contact form + details, success state |
| Footer | `src/sections/Footer.tsx` | Minimal footer with logo, links, copyright |
| ParticleCanvas | `src/components/ParticleCanvas.tsx` | Canvas particle background system |

### 2.3 Custom Hooks

| Hook | File | Description |
|------|------|-------------|
| useScrollReveal | `src/hooks/useScrollReveal.ts` | Intersection Observer for scroll-triggered fade-in animations |
| useCountUp | `src/hooks/useCountUp.ts` | Animated counter from 0 to target value |

---

## 3. Animation Implementation

| Animation | Library / Approach | Implementation | Complexity |
|-----------|-------------------|----------------|------------|
| Particle Canvas Background | Canvas 2D API | `requestAnimationFrame` loop, 80-100 particles with upward drift + sine-wave horizontal oscillation, visibility-aware pause | **High** |
| Scroll-Triggered Fade-In | Intersection Observer API + CSS | `useScrollReveal` hook adds `.revealed` class → CSS transitions opacity + translateY, stagger via `--stagger-index` CSS var | **Low** |
| Stat Counter Animation | Custom hook (`useCountUp`) | `requestAnimationFrame`-based count from 0 to target over 2s with easeOut easing, triggered by Intersection Observer | **Medium** |
| Hero Entrance Sequence | CSS keyframes + inline styles | Sequential fade-in + translateY with increasing `animation-delay` values (0.3s, 0.5s, 0.7s) | **Low** |
| Card Hover Glow | CSS transitions | Border-color, box-shadow, transform transitions on `:hover` | **Low** |
| Navbar Scroll State | Scroll event listener | Toggle class on scroll > 50px → CSS transition for background opacity + box-shadow | **Low** |
| CTA Button Hover | CSS transitions | Transform + box-shadow transition on hover/active | **Low** |
| Mobile Menu Toggle | CSS transitions | Height transition + staggered child fade-in with delay | **Low** |
| Scroll Indicator Bounce | CSS keyframes | Infinite translateY oscillation, 2s ease-in-out | **Low** |
| Form Success State | CSS transitions | Fade-in + scale transition on state change | **Low** |
| Input Focus Glow | CSS transitions | Border-color + box-shadow transition on `:focus` | **Low** |
| Smooth Scroll Navigation | Native CSS | `scroll-behavior: smooth` on html + `scroll-margin-top: 72px` on section anchors | **Low** |

---

## 4. State & Logic Plan

### 4.1 State Management (useState)

| State | Component | Type | Purpose |
|-------|-----------|------|---------|
| `isMenuOpen` | Navbar | boolean | Mobile menu toggle |
| `isScrolled` | Navbar | boolean | Navbar background/shadow on scroll |
| `formData` | Contact | object | Form field values {name, email, phone, service, message} |
| `isSubmitted` | Contact | boolean | Show success state after form submit |
| `errors` | Contact | object | Validation error messages per field |

### 4.2 Side Effects (useEffect)

| Effect | Component | Purpose |
|--------|-----------|---------|
| Scroll listener | Navbar | Set `isScrolled` when scrollY > 50px |
| Visibility change listener | ParticleCanvas | Pause/resume animation when tab hidden/shown |
| Canvas resize observer | ParticleCanvas | Resize canvas to match parent on window resize |
| Intersection Observer | useScrollReveal hook | Add `.revealed` class when element enters viewport |
| Intersection Observer | useCountUp hook | Trigger counter animation when stat enters viewport |

### 4.3 Form Validation Logic

- **Name**: Required, min 2 characters
- **Email**: Required, valid email format (regex)
- **Phone**: Optional, no validation
- **Service**: Required, must not be default "Select a service"
- **Message**: Required, min 10 characters
- On submit: validate all required fields → if valid, set `isSubmitted = true` → show success message

---

## 5. Other Key Decisions

### 5.1 No Routing
Single-page website — no `react-router-dom`. Navigation uses smooth scroll to section IDs.

### 5.2 No External Images
All visuals are procedural (CSS gradients, Canvas particles, Lucide icons). No image assets to generate or load. This keeps the bundle small and eliminates image loading concerns.

### 5.3 Font Loading
Inter loaded via Google Fonts `<link>` in `index.html` (weights 300-700). This avoids npm font packages and leverages browser caching.

### 5.4 Color Palette in Tailwind
Custom colors added to `tailwind.config.js` (or CSS variables in `index.css` with `@theme`):
- `bg-primary: #08080f`
- `surface: #111118`
- `neon: #00d4ff`
- `accent: #7b2ff7`
- `text-muted: #8892a4`

### 5.5 Responsive Grid for Services
- `< 768px`: 1 column
- `768px - 1023px`: 2 columns
- `≥ 1024px`: 3 columns (cards 1-3 in row 1, cards 4-5 centered in row 2)
- Achieved with Tailwind: `grid-cols-1 md:grid-cols-2 lg:grid-cols-3` plus `lg:[&:nth-child(4)]:col-start-1 lg:[&:nth-child(5)]:col-start-2` or simpler: last row auto-centered via grid flow

### 5.6 About Section Stat "24/7"
The "24/7" stat is displayed as static text (not a numeric counter) since it's not a number. The `useCountUp` hook handles numeric stats (200, 5, 500) and returns the target value immediately for non-numeric stats.
